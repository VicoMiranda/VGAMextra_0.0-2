##########################################################################
# These functions are
# Copyrigth (C) 2014-2018 V. Miranda and T. W. Yee. University of Auckland
# function Is.Numeric



XLMmat <- function(object, ...) {
  return(object@x)
}